/**
 * ISPF bridge: push DOOM session telemetry into the object tree.
 * Hub path: root.platform.singleton-blueprints.doom
 */
(function (global) {
  const HUB = "root.platform.singleton-blueprints.doom";
  const STATE = {
    phase: "title",
    health: 100,
    armor: 0,
    ammo: 50,
    kills: 0,
    secrets: 0,
    levelName: "E1M1",
    lowHealth: false,
    dead: false,
    lastHeartbeat: 0,
    cmdReset: false,
    cmdPause: false,
  };

  function resolveToken() {
    try {
      const stores = [];
      if (global.sessionStorage) stores.push(global.sessionStorage);
      if (global.localStorage) stores.push(global.localStorage);
      for (let s = 0; s < stores.length; s++) {
        const storage = stores[s];
        const raw = storage.getItem("ispf-auth-session") || storage.getItem("ispf.token");
        if (!raw) continue;
        if (raw[0] !== "{") return raw;
        try {
          const parsed = JSON.parse(raw);
          if (parsed && typeof parsed.token === "string") return parsed.token;
        } catch (_) {
          /* ignore */
        }
      }
    } catch (_) {
      /* ignore */
    }
    return "";
  }

  function authHeaders() {
    const token = resolveToken();
    const headers = { "Content-Type": "application/json" };
    if (token) headers.Authorization = "Bearer " + token;
    return headers;
  }

  async function putVariable(name, fields, row) {
    const schemaFields = Object.keys(fields).map((k) => ({ name: k, type: fields[k] }));
    const body = {
      schema: { name: name, fields: schemaFields },
      rows: [row],
    };
    const url =
      "/api/v1/objects/by-path/variables?path=" +
      encodeURIComponent(HUB) +
      "&name=" +
      encodeURIComponent(name);
    const res = await fetch(url, {
      method: "PUT",
      headers: authHeaders(),
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      console.warn("[ispf-bridge] put", name, res.status, text.slice(0, 200));
    }
    return res.ok;
  }

  async function getVariable(name) {
    const url =
      "/api/v1/objects/by-path/variables/detail?path=" +
      encodeURIComponent(HUB) +
      "&name=" +
      encodeURIComponent(name);
    const res = await fetch(url, { headers: authHeaders() });
    if (!res.ok) return null;
    const data = await res.json();
    const row = data?.value?.rows?.[0] || data?.rows?.[0] || data?.value || null;
    return row;
  }

  async function pushHud() {
    STATE.lastHeartbeat = Date.now();
    STATE.lowHealth = STATE.health > 0 && STATE.health < 25;
    STATE.dead = STATE.health <= 0;
    await Promise.all([
      putVariable("phase", { value: "STRING" }, { value: STATE.phase }),
      putVariable("health", { value: "DOUBLE", unit: "STRING" }, { value: STATE.health, unit: "hp" }),
      putVariable("armor", { value: "DOUBLE", unit: "STRING" }, { value: STATE.armor, unit: "%" }),
      putVariable("ammo", { value: "DOUBLE", unit: "STRING" }, { value: STATE.ammo, unit: "rnd" }),
      putVariable("kills", { value: "DOUBLE", unit: "STRING" }, { value: STATE.kills, unit: "n" }),
      putVariable("secrets", { value: "DOUBLE", unit: "STRING" }, { value: STATE.secrets, unit: "n" }),
      putVariable("levelName", { value: "STRING" }, { value: STATE.levelName }),
      putVariable("lowHealth", { value: "BOOLEAN" }, { value: STATE.lowHealth }),
      putVariable("dead", { value: "BOOLEAN" }, { value: STATE.dead }),
      putVariable("lastHeartbeat", { value: "DOUBLE" }, { value: STATE.lastHeartbeat }),
    ]);
  }

  async function pollCommands() {
    try {
      const resetRow = await getVariable("cmdReset");
      if (resetRow && (resetRow.value === true || resetRow.value === "true")) {
        STATE.cmdReset = true;
        await putVariable("cmdReset", { value: "BOOLEAN" }, { value: false });
        resetSession();
        if (typeof global.location !== "undefined") {
          global.location.reload();
        }
      }
      const pauseRow = await getVariable("cmdPause");
      if (pauseRow && (pauseRow.value === true || pauseRow.value === "true")) {
        STATE.phase = STATE.phase === "paused" ? "playing" : "paused";
        await putVariable("cmdPause", { value: "BOOLEAN" }, { value: false });
        await pushHud();
      }
    } catch (err) {
      console.warn("[ispf-bridge] poll", err);
    }
  }

  function resetSession() {
    STATE.phase = "playing";
    STATE.health = 100;
    STATE.armor = 0;
    STATE.ammo = 50;
    STATE.kills = 0;
    STATE.secrets = 0;
    STATE.levelName = "E1M1";
    STATE.lowHealth = false;
    STATE.dead = false;
  }

  function onGameStarted() {
    resetSession();
    pushHud();
  }

  function noteStdout(line) {
    // cloudflare doom-wasm stdout protocol: "doom: 10, game started"
    if (typeof line !== "string") return;
    if (line.indexOf("doom: 10") >= 0) {
      onGameStarted();
    }
  }

  function start(intervalMs) {
    const ms = intervalMs || 2000;
    pushHud();
    global.setInterval(function () {
      if (STATE.phase === "playing") {
        // Soft demo telemetry so CEL / dashboard widgets move without engine memory hooks.
        // Real FPS stays in WASM; these are session KPIs for the platform shell.
        STATE.lastHeartbeat = Date.now();
        pushHud();
      }
      pollCommands();
    }, ms);
  }

  global.IspfDoomBridge = {
    STATE: STATE,
    pushHud: pushHud,
    onGameStarted: onGameStarted,
    noteStdout: noteStdout,
    resetSession: resetSession,
    start: start,
    putVariable: putVariable,
  };
})(typeof window !== "undefined" ? window : globalThis);

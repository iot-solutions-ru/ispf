(function () {
  const statusEl = document.getElementById("status");
  const boot = document.getElementById("boot");
  const hudChip = document.getElementById("hudChip");
  const canvas = document.getElementById("canvas");
  const startBtn = document.getElementById("startBtn");
  const hudOnlyBtn = document.getElementById("hudOnlyBtn");

  function setStatus(t) {
    if (statusEl) statusEl.textContent = t;
  }

  function refreshChip() {
    if (!hudChip || !window.IspfDoomBridge) return;
    const s = window.IspfDoomBridge.STATE;
    hudChip.textContent =
      "phase: " + s.phase + " · HP " + s.health + " · AMMO " + s.ammo + " · KILLS " + s.kills;
  }

  function loadEngine() {
    return new Promise((resolve, reject) => {
      Promise.all([
        fetch("websockets-doom.js", { method: "HEAD" }),
        fetch("websockets-doom.wasm", { method: "HEAD" }),
        fetch("freedoom1.wad", { method: "HEAD" }),
      ])
        .then((responses) => {
          const missing = responses.find((r) => !r.ok);
          if (missing) {
            reject(
              new Error(
                "Missing engine asset (" + missing.url + "). Reinstall ui-pack assets."
              )
            );
            return;
          }
          const commonArgs = [
            "-iwad",
            "freedoom1.wad",
            "-window",
            "-nogui",
            "-nomusic",
            "-config",
            "default.cfg",
          ];
          window.Module = {
            noInitialRun: true,
            canvas: canvas,
            preRun: () => {
              Module.FS.createPreloadedFile("", "freedoom1.wad", "freedoom1.wad", true, true);
              Module.FS.createPreloadedFile("", "default.cfg", "default.cfg", true, true);
            },
            onRuntimeInitialized: () => {
              try {
                callMain(commonArgs);
                window.IspfDoomBridge.onGameStarted();
                window.IspfDoomBridge.start(2000);
                refreshChip();
                setStatus("Game running. Click canvas for keyboard focus.");
                resolve();
              } catch (err) {
                reject(err);
              }
            },
            print: (text) => {
              console.log(text);
              window.IspfDoomBridge.noteStdout(String(text));
              refreshChip();
            },
            printErr: (text) => console.error(text),
            setStatus: (text) => {
              if (text) setStatus(text);
            },
            totalDependencies: 0,
            monitorRunDependencies: function (left) {
              this.totalDependencies = Math.max(this.totalDependencies, left);
              if (left) {
                setStatus(
                  "Preparing… (" +
                    (this.totalDependencies - left) +
                    "/" +
                    this.totalDependencies +
                    ")"
                );
              }
            },
          };
          const s = document.createElement("script");
          s.src = "websockets-doom.js";
          s.onerror = () => reject(new Error("Failed to load websockets-doom.js"));
          s.onload = () => setStatus("WASM loaded, initializing…");
          document.body.appendChild(s);
        })
        .catch(reject);
    });
  }

  if (hudOnlyBtn) {
    hudOnlyBtn.addEventListener("click", async () => {
      window.IspfDoomBridge.onGameStarted();
      refreshChip();
      setStatus("HUD pushed to ISPF tree (no engine).");
    });
  }

  if (startBtn) {
    startBtn.addEventListener("click", async () => {
      setStatus("Starting…");
      try {
        await loadEngine();
        if (boot) boot.style.display = "none";
        if (canvas) canvas.focus();
      } catch (err) {
        console.error(err);
        setStatus(String(err.message || err));
      }
    });
  }

  setInterval(refreshChip, 1000);
})();

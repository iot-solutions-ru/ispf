function r(t){if(!t)return{};try{return JSON.parse(t)}catch{return{}}}export{r as p};
